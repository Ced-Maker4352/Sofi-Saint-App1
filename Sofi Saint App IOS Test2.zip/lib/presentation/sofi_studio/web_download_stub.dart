import 'package:flutter/foundation.dart';

void downloadImageBytesImpl(Uint8List bytes, String name) {}